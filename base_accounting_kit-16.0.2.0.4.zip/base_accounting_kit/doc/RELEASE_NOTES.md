## Module <base_accounting_kit>

#### 14.10.2022
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Odoo 16 accounting

#### 08.03.2023
#### Version 16.0.2.0.0
#### IMP
- Added Anglo Saxon Accounting Feature

#### 09.06.2023
#### Version 16.0.2.0.3
#### UPDT
- Bug Fix

#### 15.06.2023
#### Version 16.0.2.0.4
#### UPDT
- Bug Fix