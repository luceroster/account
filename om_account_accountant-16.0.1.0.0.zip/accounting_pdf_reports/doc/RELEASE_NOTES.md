## Module <accounting_pdf_reports>

#### 18.03.2023
#### Version 16.0.1.0.2
##### FIX
- temp remove analytic filer in TB and GL

#### 22.10.2022
#### Version 16.0.1.0.1
##### IMP
- initial release
